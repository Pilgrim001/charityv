<?php $__env->startSection('content'); ?>
<!-- ============================================================= Content Start ============================================================= -->
<div class="login">
    <h1><?php echo e(__('Login')); ?></h1>
    <form method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
        <!-- ========================== Content form =============================== -->
        <input id="email" type="email" class="<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus 
        placeholder="E-Mail Address" />
        <?php if($errors->has('email')): ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
        <?php endif; ?>
        <!-- ========================== Content form =============================== -->
        <input id="password" type="password" class="<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required placeholder="Password"/>
        <?php if($errors->has('password')): ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
        <?php endif; ?>
        <!-- ========================== Content form =============================== -->
        <button type="submit" class="btn btn-primary btn-block btn-large"><?php echo e(__('Login')); ?></button>
        <?php if(Route::has('password.request')): ?>
            <a href="<?php echo e(route('password.request')); ?>" style="color: #fff">
                <?php echo e(__('Forgot Your Password?')); ?>

            </a>
        <?php endif; ?>
    </form>
</div>
<!-- ============================================================= Content end ============================================================= -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>